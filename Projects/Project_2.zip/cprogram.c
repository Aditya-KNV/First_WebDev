#include <stdio.h>
#include <math.h>

int main() {

    int n, og, x, a, rem, p, q, res;
    printf("Enter the value of n : \n");
    scanf("%d", &n);
    x = 0; a = 0; og = n;
    while(n > 0){
        a++;
        n = n / 10;
    }
    q = a; n = og;
    while(n > 0){
        rem = n % 10;
        p = pow(rem,a);
        a = q;
        x = x + p;
        n = n / 10;
    }
    
    if(og == x) res = 1;
    else res = 0;
    printf("%d\n", res);
    return 0;
}
