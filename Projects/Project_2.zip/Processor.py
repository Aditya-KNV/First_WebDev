class Processor:
	def __init__(self, mem):
		self.opcodes = {
			'00000001': self.load,  # LOAD M(X)  M(X)->AC
			'00100001': self.store,  # STOR M(X)  AC->M(X)
			'00000101': self.add,  # ADD M(X)  M(X)+AC->AC
			'00001100': self.div,  # DIV M(X) Divide AC by M(X); put the quotient in MQ and the remainder in AC
			'00001010': self.loadMQ,  # LOAD MQ  MQ -> AC
			'00001111': self.condJumpL,  # JUMP+M(X,0:19)  If the number in the accumulator is nonnegative, take the next instruction from the left half of M(X)
			'00101000': self.pow,  # POW M(X) Calculates AC to the power of M(X) and stores it in AC
			'00011111': self.chec,  # CHEC M(X)  Checks if M(X) = AC
			'00100011': self.nop  # NOP  No operation
		}
		self.memory = mem
		self.memory[108] = bin(1)[2:].zfill(40) # M[108] = 1
		self.memory[109] = bin(10)[2:].zfill(40) # M[109] = 10
		self.PC = bin(0)[2:].zfill(12) # PC = 0
		self.MAR = bin(0)[2:].zfill(40)
		self.MBR = ''
		self.IR = ''
		self.IBR = ''
		self.AC = bin(0)[2:].zfill(40) # AC = 0 
		self.MQ = bin(0)[2:].zfill(40) # MQ = 0

	# FETCH PHASE
	def fetch(self):
		self.MAR = self.PC # MAR takes address of PC
		self.PC = bin(int(self.PC, 2) + 1)[2:].zfill(12) # PC is updated
		self.MBR = self.memory[int(self.MAR, 2)] # contents of memory in MAR is sent to MBR

	# DECODE PHASE
	def split_left(self):
		self.IR = self.MBR[:8] # opcode is stored in IR
		self.MAR = self.MBR[8:20] # address is stored in MAR
		self.IBR = self.MBR[20:] # right instruction is stored in IBR
		self.instruction(self.IR, self.MAR) 

	def split_right(self):
		self.IR = self.IBR[:8]
		self.MAR = self.IBR[8:20]
		if self.IR != '00100100': # condition for halt
			self.instruction(self.IR, self.MAR)

	# EXECUTE PHASE
	def instruction(self, opcode, address):
		self.opcodes[opcode](address)

	def load(self,x):  # LOAD M(X)
		self.MBR = self.memory[int(x,2)] # Contents of M(X) is loaded MBR
		self.AC = bin(int(self.MBR,2))[2:].zfill(40) # MBR to AC
		print(f'load m {int(x,2)}')
	
	def store(self,x):  # STOR M(X)
		self.memory[int(x,2)] = bin(int(self.AC, 2))[2:].zfill(40) # AC is stored in M(X)
		print(f'store m {int(x,2)}')

	def add(self,x):  # ADD M(X)
		self.MBR = self.memory[int(x,2)]
		self.AC = bin(int(self.AC, 2) + int(self.MBR, 2))[2:].zfill(40) 
		print(f'add m {int(x,2)}')

	def div(self,x):  # DIV M(X)
		quo = int(self.AC, 2) // int(self.memory[int(x,2)], 2)
		rem = int(self.AC, 2) % int(self.memory[int(x,2)], 2)
		self.AC = bin(rem)[2:].zfill(40) # Put remainder in AC
		self.MQ = bin(quo)[2:].zfill(40) # Quotient in MQ
		print(f'div m {int(x,2)}')

	def loadMQ(self,x):
		self.AC = self.MQ
		print('load mq')

	def condJumpL(self,x):  # JUMP+M(X,0:19)
		if int(self.AC, 2) > 0: # check condition
			print('jump')
			self.PC = x # change PC value to loop back to an address
			self.fetch()
			self.split_left()

		else: # if condition fails, continue
			print('break out of loop')

	def pow(self, x):  # POW M(X)
		self.AC = bin(int(self.AC, 2) ** int(self.memory[int(x,2)], 2))[2:].zfill(40)
		print(f'pow m {int(x,2)}')
		
	def chec(self,x):  # CHEC M(X)
		print(f'chec m {int(x,2)}')
		if self.AC == self.memory[int(x,2)]: # check if value in accumulator == M(x)
			self.AC = bin(1)[2:].zfill(40)
		else:
			self.AC = bin(0)[2:].zfill(40)

	def nop(self,x): # No Operation
		print(f'nop')

	def run(self):
		while self.IR != '00100100': # HLT condition
			self.fetch()
			self.split_left()
			self.split_right()


n = int(input()) # Take input for n
memory = []
with open('MachineCode.txt', 'r') as file:
	for line in file:
		memory.append(line.strip()) 

for i in range(len(memory), 1000): 
	memory.append('0')

memory[100] = bin(n)[2:].zfill(40) # Storing n in M(100)
pro = Processor(memory)
pro.run()

print('\n')
print("bool result:")
print(int(pro.memory[107],2)) # M(107) will contain the result

