def Instruction(snip) :
    bits = snip.split('(') # here we are getting the one of the instructions of left and right.
    if len(bits) == 2: # if the length of the bits is 1 we have so many options but some exceptional statements are jump etc.
        bits[1] = bits[1].replace(")", "")
        if "," in bits[1]: # so we write a condition for those type of statements.
            x = (bits[1].split(","))[0]
            bits[1] = x
            y = int(Opcode(bits[0]))
            y = bin(y)
            y = str(y)
            y = y[2:]
            l = len(y)
            s = ""
            # we get the opcode for the instructions.
            if l < 8: 
                s = "0" * (8 - l) + y
            instruction = s + Address(bits[1])
        else:
            y = int(Opcode(bits[0]))
            y = bin(y)
            y = str(y)
            y = y[2:]
            l = len(y)
            s = ""
            if l < 8:
                s = "0" * (8 - l) + y
            instruction = s + Address(bits[1])
    else: # for statements like hlt, nop and load mq we use this.
        y = int(Opcode(bits[0]))
        y = bin(y)
        y = str(y)
        y = y[2:]
        l = len(y)
        s = ""
        if l < 8:
            s = "0" * (8 - l) + y
        instruction = s + ("1" * 12)
    return instruction

# we defined the opcodes for the instructions we used in our assembly code.
def Opcode(bits8):
    if  bits8 == "LOAD M": # load the data in given location to ac.
        return 1
    elif bits8 == "STOR M": # store the data in given location from ac.
        return 33
    elif bits8 == "ADD M": # add the data in accumulator with data in the memory location and store it in ac.
        return 5
    elif bits8 == "DIV M": # divide the data in ac with the data in the memory location given; the quotient goes to mq and the remainder goes to the ac
        return 12
    elif bits8 == "JUMP + M": #remember all should be left i.e 0:19; this jump to the location given if the data in ac is non positive.
        return 15
    elif bits8 == "LOAD MQ": # transfer contents from mq to ac.
        return 10
    elif bits8 == "MAC M": # multiplies the contents of the ac with contents in the memory location and store the least significant bits in ac
        return 47
    elif bits8 == "SUB M": # subtracts the contents in ac with content in the memory location given.
        return 6
    elif bits8 == "CHEC M": # compares the value in ac with the memory location content.
        return 31
    elif bits8 == "NOP": # nothing operation that does nothing.
        return 35
    elif bits8 == "HLT": # stops the execution of the program.
        return 36
    elif bits8 == "POW M": # does the power of the value in ac and stores back in ac.
        return 40
# we are finding the instruction address from this function.
def Address(bits12):
    bits12 = int(bits12)
    binary = bin(bits12)
    binary = str(binary)
    binary = binary[2:]
    
    if len(binary) < 12:
        binary = "0" * (12 - len(binary)) + binary
        return binary
    elif len(binary) == 12:
        return binary
# opening the assembly code file.
with open("X1.txt", "r") as ASFile:    
    lines = ASFile.readlines()
    MC = []
    # going through each line.
    for line in lines:
        l = line.split("; ") # separating each line to left and right.
        l[1] = l[1].replace("\n", "")
        MC.append(Instruction(l[0]) + Instruction(l[1]) + "\n")# getting the final machine code.
MCFile = open("MachineCode.txt", "w")
MCFile.writelines(MC) # writing the machine code in the file MachineCode.txt.
